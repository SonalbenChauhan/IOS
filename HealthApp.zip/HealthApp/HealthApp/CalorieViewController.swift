//
//  CalorieViewController.swift
//  HealthApp
//
//  Created by Jaspreet Kaur on 2020-06-12.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//

import UIKit

class CalorieViewController: UIViewController {

    //enum for errorhandling
    enum MyErrorEnum : Error {
        case InvalidNumberError
        case NothingError
    }
    
    // Outlet bodyWeight TextField
    @IBOutlet weak var bodyWeightTextField: UITextField!
    
    // Outlet for TextField height
    @IBOutlet weak var heightTextField: UITextField!
    
    //Outlet for TextField age
    @IBOutlet weak var ageTextField: UITextField!
    
    //Outlet for Calculate Button
    @IBOutlet weak var calculateCalorieIntake: UIButton!
    
    //Outlet for result Label for Men
    @IBOutlet weak var resultLabel: UILabel!
    
    //Outlet for result Label for Women
    @IBOutlet weak var resultLabelWomen: UILabel!
    
    // Acitivity to hide keyboard when taps on the screen
    @IBAction func dismissKeyBoardOnTap(_ sender: Any) {
        bodyWeightTextField.resignFirstResponder()
        heightTextField.resignFirstResponder()
        ageTextField.resignFirstResponder()
    }
    
    // Activity for calculate Buttin
    @IBAction func calculateCalorieIntake(_ sender: Any) {
        
        //invoking the function
        do {
            let result = try calculateCalorieIntakeFunction()
            print(result)
        } catch MyErrorEnum.NothingError {
            resultLabel.text = ("Invalid input")
        }
        catch MyErrorEnum.InvalidNumberError {
            resultLabel.text = ("Input fields can't be empty")
        } catch {
            resultLabel.text = ("all exceptions")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
           super.didReceiveMemoryWarning()
           // Dispose of any resources that can be recreated.
       }
       
       
       // Function to calculate the BMR
       
       func calculateCalorieIntakeFunction() throws->NSData? {
        if(bodyWeightTextField.text == "" || heightTextField.text == "" || ageTextField.text == "")
        {
            throw MyErrorEnum.InvalidNumberError
        } else {
        //Initializing variables for textfields
           let bodyWeight: Double =
           Double(bodyWeightTextField.text!)!
           let height: Double = Double(heightTextField.text!)!
           let age: Double = Double(ageTextField.text!)!
        if(height < 0 || bodyWeight < 0 || age < 0){
                   throw MyErrorEnum.NothingError
               } else {
            var result : Double = 0
        var resultMen : Double = 0
        var resultWomen : Double = 0
           //finding the BMR for both men and women
        result = (10*bodyWeight)
        result+=(6.25*height)
        result-=(5*age)
        resultMen = result+5
        resultWomen = result-161
        
               // to show the results on screen 
           resultLabel.text =  "BMR for Men: \(String(format:"%.2f", resultMen)) "
        resultLabelWomen.text =  "BMR for Women: \(String(format:"%.2f", resultWomen))"
        return NSData(bytes:&result, length: MemoryLayout<Double>.size)
       }
        }
    }

}
