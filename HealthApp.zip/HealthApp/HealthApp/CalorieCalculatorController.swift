//
//  CalorieCalculatorController.swift
//  HealthApp
//
//  Created by Jaspreet Kaur on 2020-06-12.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//


import UIKit

class CalorieCalculatorController: UIViewController {
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
