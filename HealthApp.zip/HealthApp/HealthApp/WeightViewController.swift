//
//  WeightViewController.swift
//  HealthApp
//
//  Created by Jaspreet Kaur on 2020-06-12.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//

import UIKit

class WeightViewController: UIViewController {
    
    //enum for errorhandling
    enum MyErrorEnum : Error {
        case InvalidNumberError
        case NothingError
    }
    
// outlet for result label
    @IBOutlet weak var resultLabel: UILabel!
    
   //outlet for height TextField
    @IBOutlet weak var heightTextField: UITextField!
    
    // outlet for result Label for women
    @IBOutlet weak var resultLabelWomen: UILabel!
    
    //Outlet for age TextField
    @IBOutlet weak var ageTextField: UITextField!
    
    // Activity for Calculate Button Function
    @IBAction func calculateWeightButton(_ sender: Any) {
        // invoking calculateWeight function
        
        //invoking the function
        do {
            let result = try calculateWeight()
            print(result)
        } catch MyErrorEnum.NothingError {
            resultLabel.text = ("Invalid input")
        }
        catch MyErrorEnum.InvalidNumberError {
            resultLabel.text = ("Input fields can't be empty")
        } catch {
            resultLabel.text = ("all exceptions")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
              super.didReceiveMemoryWarning()
              // Dispose of any resources that can be recreated.
          }
    

     // Function to calculate the ideal weight
          
          func calculateWeight() throws->NSData? {
            if( heightTextField.text == "" || ageTextField.text == "")
            {
                throw MyErrorEnum.InvalidNumberError
            } else {
              //initializing text fields inputs
              let height: Double = Double(heightTextField.text!)!
              let age: Double = Double(ageTextField.text!)!
      
            if(height < 0 || age < 0 ){
                throw MyErrorEnum.NothingError
            } else {
               var result : Double = 0
           var resultMen : Double = 0
           var resultWomen : Double = 0
              
           //finding the ideal weight using formulas for both men and women
            resultMen = 50+(0.91*(height-152.4))
            resultWomen = 45.5+(0.91*(height-152.4))
           
            // setting the label values
              resultLabel.text =  "Ideal weight for Men: \(String(format:"%.2f", resultMen)) "
            resultLabelWomen.text = "Ideal weight for Women: \(String(format:"%.2f", resultWomen))"
            return NSData(bytes:&result, length: MemoryLayout<Double>.size)
            }
            }
          }
// Action to hide keyboard when taps on the screen
    @IBAction func dismissKeyBoardOnTap(_ sender: Any) {
        heightTextField.resignFirstResponder()
        ageTextField.resignFirstResponder()
    }
}
