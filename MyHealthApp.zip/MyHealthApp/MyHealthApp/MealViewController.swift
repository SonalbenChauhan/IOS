//
//  MealViewController.swift
//  MyHealthApp
//
//  Created by Li Yas on 2020-07-24.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//

import UIKit
// meal controller
class MealViewController: UIViewController, UITextFieldDelegate {
        
    @IBOutlet weak var mealTextField: UITextField!
    var update: (() -> Void)?

         override func viewDidLoad() {
            // view load
             super.viewDidLoad()
             mealTextField.delegate = self
            // adding a new navigation bar item
             navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveMeal))
            // variable to recognise tap
             let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
             tap.cancelsTouchesInView = false
            // adding gesture recognizer
             self.view.addGestureRecognizer(tap)
         }
         
         func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // calling the savemeal function
             saveMeal()
            // returning true value
             return true
         }
         
         // function to save the meal value to userdefaults array
         @objc func saveMeal(){
            // getting value from text field
             guard let text = mealTextField.text, !text.isEmpty else{
                 return
             }
            // gettiung the count of meal array to variable
             guard let mealCount = UserDefaults().value(forKey: "count") as? Int else {
                 return
             }
            // adding one to the meal array count
             let newMealCount = mealCount + 1
            // setting userdefault count value
             UserDefaults().set(newMealCount, forKey: "count")
            // setting meal array to userdefaults
             UserDefaults().set(text, forKey: "meal_\(newMealCount)")
             update?()
            // adding animation for the viewcontroller popup
             navigationController?.popViewController(animated: true)
         }
         @objc func dismissKeyboard(){
             self.view.endEditing(true)
         }
    
    // Action to hide keyboard when taps on the screen
    @IBAction func dismissKeyBoardOnTap(_ sender: Any) {
        mealTextField.resignFirstResponder()
    }
}
