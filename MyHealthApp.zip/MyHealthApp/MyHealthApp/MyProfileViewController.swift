//
//  MyProfileViewController.swift
//  MyHealthApp
//
//  Created by Li Yas on 2020-07-24.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//


import UIKit
// profile View Controller
class MyProfileViewController: UIViewController {
    var update: (() -> Void)?
    //enum for errorhandling
    enum MyErrorEnum : Error {
        case InvalidNumberError
        case NothingError
    }
    // outlet for nameTextFiels
    @IBOutlet weak var nameTextField: UITextField!
    // outlet for emailTextField
    @IBOutlet weak var emailTextField: UITextField!
    // outlet for save button
    @IBOutlet weak var saveButton: UIButton!
    // outlet for edit Button
    @IBOutlet weak var editButton: UIButton!
    
    override func viewDidLoad() {
           super.viewDidLoad()
        // getting the name value from userdefaultys
        guard let name = UserDefaults().value(forKey: "name") as? String else {
            return
        }
        // setting that value to the textfdield
        nameTextField.text = name
        // Disabling the text field
        nameTextField.isUserInteractionEnabled = false;
        // getting the email value from userdefaultys
        guard let email = UserDefaults().value(forKey: "email") as? String else {
            return
        }
        // setting that value to the textfdield
        emailTextField.text = email
        //disabling the text field
        emailTextField.isUserInteractionEnabled = false;
           // Do any additional setup after loading the view.
        // hiding the savebutton
        saveButton.isHidden = true
        // showing the edit button
        editButton.isHidden = false
        
       }
       
       override func didReceiveMemoryWarning() {
                 super.didReceiveMemoryWarning()
                 // Dispose of any resources that can be recreated.
             }
    // tap gesture button
    @IBAction func tapGestureClickAction(_ sender: Any) {
        nameTextField.resignFirstResponder()
        emailTextField.resignFirstResponder()
    }
    // edit button click action
    @IBAction func editButtonClick(_ sender: Any) {
        // hiding the edit button
        editButton.isHidden = true
        //showing the save button
        saveButton.isHidden = false
        // enabling the text fields
        emailTextField.isUserInteractionEnabled = true;
        nameTextField.isUserInteractionEnabled = true;
    }
    
    // save button click action
    @IBAction func saveClick(_ sender: Any) {
        // getting name from textfiled
        let name = nameTextField.text
        //setting this value to userdefaluts
        UserDefaults().set(name, forKey: "name")
        // getting email from textfiled
        let email = emailTextField.text
        //setting this value to userdefaluts
        UserDefaults().set(email, forKey: "email")
        update?()
        // hiding the save button and showing the edit button
        saveButton.isHidden = true
        editButton.isHidden = false
        // disabling the the textfields
        emailTextField.isUserInteractionEnabled = false;
        nameTextField.isUserInteractionEnabled = false;
    }
    
    
}
