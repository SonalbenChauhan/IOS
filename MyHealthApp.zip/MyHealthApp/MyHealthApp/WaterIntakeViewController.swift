//
//  WaterIntakeViewController.swift
//  MyHealthApp
//
//  Created by Li Yas on 2020-07-24.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//


import UIKit

class WaterIntakeViewController: UIViewController {

    //enum for errorhandling
    enum MyErrorEnum : Error {
        case InvalidNumberError
        case NothingError
    }
    
    //outlet for text field Body weight
    
    @IBOutlet weak var bodyWeightTextField: UITextField!
    //outlet for text field minutes of exercise
    
    @IBOutlet weak var exerciseTextField: UITextField!
    //outlet for result label
    @IBOutlet weak var resultLabel: UILabel!
    
    // calculate button action
       
    @IBAction func calculateClickAction(_ sender: Any) {
        //invoking the function
        do {
            let result = try calculateWaterIntake()
            print(result)
        } catch MyErrorEnum.NothingError {
            resultLabel.text = ("Invalid input")
        }
        catch MyErrorEnum.InvalidNumberError {
            resultLabel.text = ("Input fields can't be empty")
        } catch {
            resultLabel.text = ("all exceptions")
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Action that invokes when taps on the screen. To hide the keyboard
    @IBAction func dismissKeyBoardOnTap(_ sender: Any) {
        bodyWeightTextField.resignFirstResponder()
        exerciseTextField.resignFirstResponder()
    }
    
    // Function to calculate the water intake
    
    func calculateWaterIntake() throws->NSData? {
        if(bodyWeightTextField.text == "" || exerciseTextField.text == "")
        {
            throw MyErrorEnum.InvalidNumberError
        } else {
        // getting values from text fields
        let bodyWeight: Double =
        Double(bodyWeightTextField.text!)!
       
        let minutesExercise: Double = Double(exerciseTextField.text!)!
        // initializing variable result as 0
        if(minutesExercise < 0 || bodyWeight < 0){
            throw MyErrorEnum.NothingError
        } else {
         var result : Double = 0
        // calculating water intake
        result = bodyWeight * (2/3)
        result += (minutesExercise/30)*12
        //setting label with string
        resultLabel.text =  "Drink \(String(format:"%.2f", result)) ounces per day."
            return NSData(bytes:&result, length: MemoryLayout<Double>.size)
        }
        }
    
}
}


