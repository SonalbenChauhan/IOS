//
//  CalorieCalculatorController.swift
//  MyHealthApp
//
//  Created by Li Yas on 2020-07-24.
//  Copyright © 2020 Kavitha Vijayan. All rights reserved.
//


import UIKit

// controller to add meals
// implementing table view

class CalorieCalculatorController: UIViewController, UITextFieldDelegate, UITableViewDelegate {
    //enum for errorhandling
    enum MyErrorEnum : Error {
        case InvalidNumberError
        case NothingError
    }
    
var newEntry: String = ""
    // array to save meal entries
var meals = [String]()
    // outlet for table View
    @IBOutlet weak var tableView: UITableView!
    // function to update userdefaults
    var update: (() -> Void)?
    @IBAction func AddButtonClicked(_ sender: Any) {
        insertCalorieEntry()
    }
    
    override func viewDidLoad() {
            super.viewDidLoad()
            self.title = "Meals"
            // setting tableview delegate and datasource with self
            tableView.delegate = self
            tableView.dataSource = self
        // checking userdefaults value
            if !UserDefaults().bool(forKey: "setup"){
                // setting userdefaults values
                UserDefaults().set(true, forKey: "setup")
                UserDefaults().set(0, forKey: "count")
            }
        // calling updateMeals function
            updateMeals()
        }
    // definition of updateMeals funstion
        func updateMeals(){
            // remoning items from meals array
            meals.removeAll()
            // getting userdefaults count value
            guard let count = UserDefaults().value(forKey: "count") as? Int else {
                return
            }
            // getting the meal values from userdefaults array
            for x in 0..<count {
                // string value of all individual meals
                if let meal = UserDefaults().value(forKey: "meal_\(x+1)") as? String {
                    // adding the item to meals array
                    meals.append(meal)
                }
            }
            // funstion to reload tableView
            tableView.reloadData()
            
        }
        // funstion to invoke MealViewController
        func insertCalorieEntry(){
            let viewController = storyboard?.instantiateViewController(identifier:"meal") as! MealViewController
            // setting the title as New Meal
            viewController.title = "New Meal"
    // funstion to update the meal array
            viewController.update = {
                DispatchQueue.main.async {
                    self.updateMeals()
                }
            }
            // opening the viewcontroller
            navigationController?.pushViewController(viewController, animated: true)
            
            
            
        }
        
    }
// extended funstions of tableView
    extension CalorieCalculatorController: UITableViewDataSource{
        // funstion to return meals count
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return meals.count
        }
        // funstion that adds the text to row
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let myCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            myCell.textLabel?.text = meals[indexPath.row]
            return myCell
        }
        
        // enabling the table view edit feature
        func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
            return true;
        }
        // deleting the values in able view
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if (editingStyle == .delete)
            {
                // removing frpom the array
                meals.remove(at: indexPath.row)
                // gettiung the count of meal array to variable
                 guard let mealCount = UserDefaults().value(forKey: "count") as? Int else {
                     return
                 }
                // adding one to the meal array count
                 let newMealCount = mealCount - 1
                // setting userdefault count value
                 UserDefaults().set(newMealCount, forKey: "count")
                UserDefaults().removeObject(forKey: "meal_\(indexPath.row)")
                // begin updsates
                tableView.beginUpdates()
                //deleting the row from table
                tableView.deleteRows(at: [indexPath], with: .automatic)
                // end updates
                tableView.endUpdates()
            }
        }
    }
